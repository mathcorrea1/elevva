# Acessibilidade Avançada

## WCAG 2.1 — Checklist Prático

### Nível A (Obrigatório)
- [ ] Imagens com `alt` descritivo (ou `alt=""` se decorativa)
- [ ] Vídeos com legendas
- [ ] Conteúdo não depende só de cor para transmitir informação
- [ ] Sem conteúdo que pisca mais de 3x/segundo
- [ ] Skip links ("Pular para conteúdo principal")
- [ ] Títulos em ordem lógica (h1 → h2 → h3, sem pular)
- [ ] Labels em todos os inputs
- [ ] Mensagens de erro identificam o campo com problema

### Nível AA (Recomendado)
- [ ] Contraste texto normal: 4.5:1
- [ ] Contraste texto grande (18px+): 3:1
- [ ] Contraste elementos UI (bordas, ícones): 3:1
- [ ] Texto redimensionável até 200% sem perda de funcionalidade
- [ ] Foco visível em todos os interativos
- [ ] Ordem de foco lógica (não aleatória)
- [ ] Erros sugeridos (não só "campo inválido")
- [ ] Autofill em campos de formulário pessoal

## Ferramentas para Verificar Contraste

### Fórmula de contraste relativo
```
Razão = (L1 + 0.05) / (L2 + 0.05)
L = luminância relativa (0–1)
```

### Combinações seguras (exemplos)
| Fundo | Texto | Razão | Status |
|-------|-------|-------|--------|
| #FFFFFF | #374151 | 10.7:1 | ✅ AAA |
| #FFFFFF | #6B7280 | 4.6:1 | ✅ AA |
| #FFFFFF | #9CA3AF | 2.8:1 | ❌ Falha |
| #1F2937 | #F9FAFB | 16.1:1 | ✅ AAA |
| #3B82F6 | #FFFFFF | 4.6:1 | ✅ AA |
| #EF4444 | #FFFFFF | 4.0:1 | ❌ Falha (use #DC2626) |

## ARIA Essencial

### Roles Comuns
```html
<!-- Navegação -->
<nav aria-label="Menu principal">
<nav aria-label="Breadcrumb">

<!-- Regiões -->
<main>
<header>
<footer>
<aside aria-label="Sidebar de filtros">

<!-- Widgets -->
<button aria-pressed="true">Like</button>
<button aria-expanded="false" aria-controls="menu-id">Menu</button>
<div role="dialog" aria-labelledby="dialog-title" aria-modal="true">

<!-- Estado -->
<input aria-required="true">
<input aria-invalid="true" aria-describedby="error-id">
<div aria-live="polite">Carregando...</div>
<div aria-live="assertive">Erro crítico!</div>
```

### Live Regions
Use para conteúdo que muda dinamicamente:
```html
<!-- Para notificações não urgentes -->
<div aria-live="polite" aria-atomic="true">
  <!-- Mensagem de sucesso após salvar -->
</div>

<!-- Para alertas urgentes -->
<div role="alert">
  <!-- Erros críticos -->
</div>
```

## Focus Management

### Regras
1. Modal abre → foco vai para o modal
2. Modal fecha → foco volta ao elemento que o abriu
3. Rotas mudam (SPA) → foco vai para o h1 ou container principal
4. Conteúdo dinâmico adiciona → anuncie via aria-live

### Focus Trap em Modal (React)
```jsx
import { useEffect, useRef } from 'react';

function Modal({ isOpen, onClose, children }) {
  const modalRef = useRef(null);
  
  useEffect(() => {
    if (!isOpen) return;
    
    const focusable = modalRef.current.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    
    first?.focus();
    
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') {
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);
  
  return (
    <div ref={modalRef} role="dialog" aria-modal="true">
      {children}
    </div>
  );
}
```

## Acessibilidade em React Native

```jsx
// Botão acessível
<TouchableOpacity
  accessible={true}
  accessibilityLabel="Adicionar ao carrinho"
  accessibilityHint="Toque duas vezes para adicionar este produto"
  accessibilityRole="button"
  accessibilityState={{ disabled: isLoading }}
>

// Imagem decorativa
<Image accessible={false} />

// Imagem com descrição
<Image accessibilityLabel="Foto do produto: Tênis branco tamanho 42" />

// Agrupamento
<View accessible={true} accessibilityLabel="Preço: R$ 299,90. Em estoque.">
  <Text>R$ 299,90</Text>
  <Text>Em estoque</Text>
</View>
```

## Testes de Acessibilidade

### Ferramentas
- **axe DevTools** (extensão Chrome) — detecta 57% dos problemas automaticamente
- **WAVE** — overlay visual no browser
- **Lighthouse** — aba Accessibility no DevTools
- **VoiceOver** (Mac/iOS) e **TalkBack** (Android) — teste real com leitor de tela

### Teste Manual Básico (5 minutos)
1. Navegue pela tela só com Tab — faz sentido a ordem?
2. Ative VoiceOver/Narrator — o conteúdo é lido corretamente?
3. Aumente zoom para 200% — layout quebra?
4. Desative CSS — o conteúdo ainda faz sentido?
