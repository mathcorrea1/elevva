# Motion & Microinterações

## Princípios de Animação para UI

### As 4 Funções da Animação
1. **Feedback** — confirmar que a ação foi registrada
2. **Orientação** — mostrar onde o usuário está ou para onde vai
3. **Foco** — direcionar atenção ao que importa
4. **Personalidade** — transmitir o tom da marca

### Durações de Referência
| Tipo | Duração | Uso |
|------|---------|-----|
| Micro (hover, toggle) | 100–150ms | Botões, checkboxes, switches |
| Pequena | 200–300ms | Tooltips, dropdowns, fade in/out |
| Média | 300–500ms | Modais, drawers, page transitions |
| Grande | 500–800ms | Onboarding, empty states, splash |

### Curvas de Easing
```css
/* Entrar na tela (decelerando) */
--ease-out: cubic-bezier(0.0, 0.0, 0.2, 1);

/* Sair da tela (acelerando) */
--ease-in: cubic-bezier(0.4, 0.0, 1, 1);

/* Reposicionar (acelera e desacelera) */
--ease-in-out: cubic-bezier(0.4, 0.0, 0.2, 1);

/* Elástico sutil */
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
```

**Regra**: Elementos que entram usam `ease-out`. Elementos que saem usam `ease-in`.

---

## CSS — Animações de Alto Impacto

### Fade In + Slide Up (entrada padrão)
```css
@keyframes fadeSlideUp {
  from {
    opacity: 0;
    transform: translateY(16px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-in {
  animation: fadeSlideUp 300ms cubic-bezier(0.0, 0.0, 0.2, 1) both;
}

/* Stagger em listas */
.list-item:nth-child(1) { animation-delay: 0ms; }
.list-item:nth-child(2) { animation-delay: 60ms; }
.list-item:nth-child(3) { animation-delay: 120ms; }
.list-item:nth-child(4) { animation-delay: 180ms; }
```

### Skeleton Loading
```css
@keyframes shimmer {
  0% { background-position: -200% center; }
  100% { background-position: 200% center; }
}

.skeleton {
  background: linear-gradient(
    90deg,
    #F0F0F0 25%,
    #E0E0E0 50%,
    #F0F0F0 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 4px;
}
```

### Botão com Feedback Tátil
```css
.btn {
  transition: transform 150ms var(--ease-out),
              box-shadow 150ms var(--ease-out),
              background-color 150ms;
}

.btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.btn:active {
  transform: translateY(0) scale(0.98);
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
```

### Notificação Toast
```css
@keyframes toastIn {
  from {
    opacity: 0;
    transform: translateY(100%) scale(0.9);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

@keyframes toastOut {
  from {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
  to {
    opacity: 0;
    transform: translateY(8px) scale(0.95);
  }
}
```

---

## Framer Motion (React)

### Configurações Padrão Reutilizáveis
```jsx
// variants.js
export const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.3, ease: [0, 0, 0.2, 1] }
  },
  exit: { opacity: 0, y: 8, transition: { duration: 0.2 } }
};

export const stagger = {
  visible: {
    transition: { staggerChildren: 0.06 }
  }
};

export const scaleIn = {
  hidden: { scale: 0.95, opacity: 0 },
  visible: { 
    scale: 1, 
    opacity: 1,
    transition: { type: 'spring', stiffness: 300, damping: 25 }
  }
};
```

### Uso
```jsx
import { motion, AnimatePresence } from 'framer-motion';
import { fadeUp, stagger } from './variants';

// Lista com stagger
function ProductList({ items }) {
  return (
    <motion.ul variants={stagger} initial="hidden" animate="visible">
      {items.map(item => (
        <motion.li key={item.id} variants={fadeUp}>
          <ProductCard {...item} />
        </motion.li>
      ))}
    </motion.ul>
  );
}

// Modal com AnimatePresence
function Modal({ isOpen, children }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          <motion.div
            className="modal"
            variants={scaleIn}
            initial="hidden"
            animate="visible"
            exit="hidden"
          >
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
```

### Layout Animations (reordenação automática)
```jsx
// Adicionar/remover itens com animação suave
<motion.div layout>
  {items.map(item => (
    <motion.div
      key={item.id}
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
    >
      {item.content}
    </motion.div>
  ))}
</motion.div>
```

---

## React Native — Animações

### Animated API (built-in)
```jsx
import { Animated, Easing } from 'react-native';

// Fade in
const opacity = useRef(new Animated.Value(0)).current;

useEffect(() => {
  Animated.timing(opacity, {
    toValue: 1,
    duration: 300,
    easing: Easing.out(Easing.ease),
    useNativeDriver: true, // SEMPRE para opacity e transform
  }).start();
}, []);

// Spring para feedback tátil
const scale = useRef(new Animated.Value(1)).current;

const onPressIn = () => {
  Animated.spring(scale, {
    toValue: 0.96,
    useNativeDriver: true,
    speed: 30,
  }).start();
};

const onPressOut = () => {
  Animated.spring(scale, {
    toValue: 1,
    useNativeDriver: true,
    speed: 20,
  }).start();
};
```

### Reanimated 2 (recomendado para performance)
```jsx
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  FadeIn,
  SlideInRight,
} from 'react-native-reanimated';

// Entrada de tela
<Animated.View entering={FadeIn.duration(300)}>

// Slide de item
<Animated.View entering={SlideInRight.delay(index * 60)}>

// Spring interativo
const scale = useSharedValue(1);
const animatedStyle = useAnimatedStyle(() => ({
  transform: [{ scale: scale.value }],
}));

const handlePress = () => {
  scale.value = withSpring(0.95, { damping: 15 }, () => {
    scale.value = withSpring(1);
  });
};
```

---

## Prefers Reduced Motion

**SEMPRE** respeite a preferência do usuário:

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

```jsx
// React
import { useReducedMotion } from 'framer-motion';

function Component() {
  const shouldReduce = useReducedMotion();
  return (
    <motion.div
      animate={{ x: shouldReduce ? 0 : 100 }}
      transition={{ duration: shouldReduce ? 0 : 0.3 }}
    />
  );
}
```
