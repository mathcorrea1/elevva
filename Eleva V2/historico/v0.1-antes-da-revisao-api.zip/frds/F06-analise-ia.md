# F06 — Análise assistida, recomendações e revisão

## Objetivo, fontes e situação

Gerar orientação individual a partir de evidências e manter controle humano. **PDF** RF005/006/009 O, UC006/007/009 NI (pp.37–44), contexto pp.13–18 e restrição pedagógica p.37. **CÓD** E08/E09: serviços Gemini/STT no cliente, parse/fallback sem validação, recomendações fictícias. Situação: parcial/simulada, **sem chamada real validada** nesta tarefa. **USU** exige modelo/executor concretos. **PROP** Qwen3-4B `qwen3:4b` via Ollama no PC, backend FastAPI, conforme [decisão completa](../07-ia.md).

## Atores/permissões; pré/pós

Adulto com vínculo solicita e lê; revisor conforme escopo aceita/edita/rejeita; criança não conversa com modelo. Pré: evidências autorizadas, corpus e instrumento versionados, dependência IA pronta e cota disponível. Pós: execução rastreável com saída validada ou falha explícita; recomendações revisadas publicadas; nível só muda por confirmação F03.

## Campos, validações e regras

Cliente envia purpose e IDs de evidências; backend minimiza e monta prompt, não aceita prompt arbitrário de criança. Saída status/suggestedLevel/evidenceIds/observations/recommendations/guidance/limitations; schema fechado, IDs permitidos, limites e nulabilidade conforme07-ia. Origin live/cached/pregenerated, data/model/digest/prompt/instrumentVersion e revisor são envelope do servidor.

Sem diagnóstico ou alegações de visão/STT/Libras. Dados insuficientes→nível null; não fazer parse por substring nem fallback para pré-silábico. Recomendar somente atividade/conteúdo do catálogo autorizado. Revisão humana obrigatória antes de publicar para uso pedagógico; ajustes preservam saída original e justificativa. Nenhum segredo ou endpoint de Ollama no bundle do app.

## Fluxo principal e alternativas

1. T15 identifica dados/data e limitações; adulto solicita análise.
2. Backend verifica vínculo, suficiência definida em D03 e cota; monta pacote minimizado, cria run202 e executa pelo adaptador local.
3. Schema e regras de referências validam saída; resultado é salvo como rascunho de IA.
4. Adulto vê evidências/fontes e aceita/edita/rejeita; API registra revisão/publicação. Confirmar nível abre F03.
5. Nova evidência produz nova análise/hash; resultados anteriores datados permanecem históricos.

Alternativas: insuficiente→orientar novas evidências sem inferir; timeout/schema inválido/modelo indisponível→falha e último confirmado preservado; cota429→retryAfter; cache→origem/data explícitos; pregerado de contingência→identificado e não conta como integração real. Solicitação de conta revogada é bloqueada em execução e leitura; rechecagem antes da publicação.

## Dados, persistência e integrações

ai_runs/ai_reviews e referências autorizadas no PG; resultados não substituem eventos de avaliação. Cache segregado por estudante/hash/versões, proposta24h. Limite técnico inicial1 inferência simultânea,60s timeout,10/dia/adulto e2/min, ajustável após ensaio, sem confundir com critério pedagógico. Arquitetura local, licença, custos e alternativas em07-ia; Gemini Developer API não é fallback elegível pelos termos consultados.

## UI, acessibilidade e temas

T15/T10: geração não bloqueia navegação; status textual consultável ao retornar; “Sugestão da IA — revisar”, fontes, recorte e data. Sem parágrafos enormes na abertura: resumo e ação de abrir evidências. Todos os temas, foco na chegada do resultado só se usuário permanecer e esperar, anúncio não repetitivo, TTS opcional sem autoplay; tradução Libras humana só para explicações estáticas cobertas, não prometer texto dinâmico traduzido.

## Critérios de aceite

- **A1:** uma chamada real analisa evidências persistidas, retorna schema válido com referências existentes e origens/digest verificáveis; nível só confirma em F03.
- **A2:** casos sintéticos contrastantes geram justificativas/recomendações pertinentes ao dado segundo revisor; mudar nome não é prova de personalização.
- **A3:** timeout/insuficiência/JSON inválido não altera nível/plano; retry/cache não duplica execução indevidamente; indisponibilidade visível e registros anteriores conservados.
- **A4:** conta sem vínculo não consulta/solicita/revisa análise; pacote sem identificadores/diagnósticos; nenhuma chave no cliente; instrução maliciosa de observação não controla ferramentas.
- **A5:** revisor aceita/edita/rejeita e decisão/data/autoria reaparecem após reabrir. Pré-gerado rotulado nunca satisfaz A1.

## Dependências/decisões

F01–F04/F07, corpus/revisão D03 e runtime D12. Hardware inventariado; modelo/runtime não instalados e qualidade não testada. Critério pedagógico bloqueado até revisão; chamada técnica com dados sintéticos pode ser ensaiada separadamente sem alegar eficácia.
