# Eleva V2 — especificação para revisão

Referência: **22/10/2026**, America/Sao_Paulo. Versão documental 0.1. **Especificação elaborada; decisões pedagógicas e operacionais ainda abertas. Não é uma declaração de implementação ou conformidade.**

Recomendação: reconstruir gradualmente **telas, tema e navegação**, aproveitando React Native/Expo/TypeScript, componentes úteis, fachadas de serviços e conceitos de domínio. Corrigir regras e contratos antes de reutilizá-los. Não há justificativa comprovada para reescrever tudo.

## Ordem de leitura

1. [Visão e escopo](01-visao-escopo.md).
2. [Auditoria e comparação de caminhos](02-auditoria.md).
3. [Rastreabilidade: 10 RF, 8 RNF, 14 UC e capacidades adicionais](03-rastreabilidade.md).
4. [Decisões, conflitos e pendências](04-decisoes.md).
5. [Arquitetura e organização por features](05-arquitetura.md).
6. [UX, catálogo, estados, temas e acessibilidade](06-ux-acessibilidade.md).
7. [IA: decisão, contratos e validação](07-ia.md).
8. [Dados, API, segurança e ambiente](08-dados-api-ambiente.md).
9. [Plano, testes e roteiro da banca](09-plano-testes-banca.md).
10. [FRDs e regras comuns](frds/00-regras-comuns.md); [wireframes navegáveis locais](wireframes/index.html) e [versão textual](wireframes/catalogo.md).

## FRDs

| Documento | Responsabilidade |
|---|---|
| [F01](frds/F01-contas.md) | Cadastro, login, recuperação, sessão, saída e perfil |
| [F02](frds/F02-criancas-vinculos.md) | Crianças, necessidades, convite, concessão e revogação de acesso |
| [F03](frds/F03-avaliacao.md) | Avaliação inicial e reavaliação, evidências e nível |
| [F04](frds/F04-atividades-observacoes.md) | Atividade no app e registro pelo adulto |
| [F05](frds/F05-trilhas.md) | Trilhas, tarefas, conclusão e desbloqueio |
| [F06](frds/F06-analise-ia.md) | Análise, recomendações e revisão humana |
| [F07](frds/F07-conteudo-docente.md) | Orientações gerais, individuais e autoria docente |
| [F08](frds/F08-relatorios.md) | Histórico, progresso, relatórios individuais/bimestrais/coletivos |
| [F09](frds/F09-contexto-docente.md) | Escola, turma e acompanhamento docente |
| [F10](frds/F10-preferencias-acessibilidade.md) | Preferências, temas, leitura e Libras |
| [F11](frds/F11-feedback.md) | Feedback e participação futura, desejáveis |

## O que foi efetivamente verificado

Leitura integral do texto das 63 páginas via `Eleva-TCC.md`; abertura das figuras 21–29 individualmente e das demais em pranchas de contexto; conferência visual do PDF original nas tabelas das páginas físicas 28 e 38. As outras páginas de tabelas renderizadas ficam como evidência de apoio, sem alegação de revisão visual integral do PDF. As referências neste pacote usam **página física**, seguidas da impressa quando útil (da física 13 em diante: impressa = física − 6).

`ModeloEntregaFinal (1)(2).pdf` **não foi encontrado com esse nome**. A cópia `alfabeta/Eleva-para-Codex/Eleva-TCC-original.pdf` está acessível e tem 63 páginas; não foi possível comparar os hashes com o arquivo de nome original ausente. Não foi localizado `AGENTS.md` no workspace ou nos diretórios ancestrais pesquisados.

Inspeção estática do código atual; TypeScript e lint aprovados. Jest: uma suíte aprovada e duas falhas antes da execução dos testes de Button. Abertura do **dist preexistente**, datado de 04/05/2026: travou no splash por SecureStore; não equivale a executar o código atual. Não foram feitos build nativo, teste com crianças, avaliação assistiva completa, chamada de IA, conexão a banco ou verificação de uma conta de nuvem.

O aplicativo e as sete alterações prévias foram preservados. Não houve instalação de serviços/modelos, refatoração, commit, publicação ou provisionamento. [Evidências](evidencias/LEITURA-E-VERIFICACOES.md), [contraste dos tokens](evidencias/contraste-tokens.md) e [manifesto de hashes](evidencias/manifesto-leitura.json) permitem conferir a origem desta análise.

O usuário confirmou demonstração em APK Android e web neste computador, em aproximadamente um mês, sem data fechada. Não existe VM nem revisão pedagógica/Libras disponível no momento. O plano registra essas dependências e não exige contratar nuvem para começar.

## Convenção de evidência e conclusão

**PDF** = requisito original; **CÓD** = comportamento observado no código; **USU** = pedido atual; **PROP** = solução recomendada, ainda não aprovada pelo usuário; **PEND** = decisão/validação necessária. Uma FRD descrita não torna um requisito implementado. Status funcionais constam na matriz e só deverão mudar com evidência de implementação e teste integrado.
